(() => {
  "use strict";

  const form = document.getElementById("signupForm");
  const email = document.getElementById("email");
  const birthdate = document.getElementById("birthdate");
  const birthdateFeedback = document.getElementById("birthdateFeedback");
  const password = document.getElementById("password");
  const confirmPassword = document.getElementById("confirmPassword");
  const genderRadios = form.querySelectorAll('input[name="gender"]');
  const genderFeedback = document.getElementById("genderFeedback");
  const terms = document.getElementById("terms");

  const formView = document.getElementById("formView");
  const successView = document.getElementById("successView");
  const successEmail = document.getElementById("successEmail");

  const MIN_AGE = 13;

  /* ---------- Date of birth limits ---------- */
  const today = new Date();
  const toISO = (d) => d.toISOString().split("T")[0];
  birthdate.max = toISO(today);
  birthdate.min = "1900-01-01";

  function validateBirthdate() {
    birthdate.setCustomValidity("");
    if (!birthdate.value) {
      birthdateFeedback.textContent = "Select your date of birth.";
      return;
    }
    const dob = new Date(birthdate.value);
    let age = today.getFullYear() - dob.getFullYear();
    const hadBirthday =
      today.getMonth() > dob.getMonth() ||
      (today.getMonth() === dob.getMonth() && today.getDate() >= dob.getDate());
    if (!hadBirthday) age--;

    if (dob > today) {
      birthdate.setCustomValidity("future");
      birthdateFeedback.textContent = "Date of birth can't be in the future.";
    } else if (age < MIN_AGE) {
      birthdate.setCustomValidity("underage");
      birthdateFeedback.textContent = `You must be at least ${MIN_AGE} years old to sign up.`;
    }
  }

  /* ---------- Password rules + strength ---------- */
  const rules = {
    length: (v) => v.length >= 8,
    case: (v) => /[a-z]/.test(v) && /[A-Z]/.test(v),
    number: (v) => /\d/.test(v),
  };
  const bar = document.getElementById("strengthBar");
  const barWrap = document.getElementById("strengthBarWrap");
  const label = document.getElementById("strengthLabel");

  function updateStrength() {
    const v = password.value;
    let score = 0;
    Object.entries(rules).forEach(([key, test]) => {
      const ok = test(v);
      const li = document.querySelector(`[data-rule="${key}"]`);
      li.classList.toggle("ok", ok);
      li.querySelector("i").className = ok ? "bi bi-check-circle-fill" : "bi bi-circle";
      if (ok) score++;
    });
    if (/[^A-Za-z0-9]/.test(v) && v.length >= 8) score++; // bonus for symbols

    const levels = [
      { pct: 0,   text: "",       cls: "" },
      { pct: 25,  text: "Weak",   cls: "bg-danger" },
      { pct: 50,  text: "Fair",   cls: "bg-warning" },
      { pct: 75,  text: "Good",   cls: "bg-info" },
      { pct: 100, text: "Strong", cls: "bg-success" },
    ];
    const lvl = v ? levels[Math.min(score, 4) || 1] : levels[0];
    bar.style.width = lvl.pct + "%";
    bar.className = "progress-bar " + lvl.cls;
    barWrap.setAttribute("aria-valuenow", lvl.pct);
    label.textContent = lvl.text;

    const allOk = Object.values(rules).every((t) => t(v));
    password.setCustomValidity(allOk ? "" : "weak");
  }

  function checkMatch() {
    confirmPassword.setCustomValidity(
      confirmPassword.value && confirmPassword.value === password.value ? "" : "mismatch"
    );
  }

  /* ---------- Show / hide password ---------- */
  document.querySelectorAll(".toggle-pw").forEach((btn) => {
    btn.addEventListener("click", () => {
      const input = document.getElementById(btn.dataset.target);
      const show = input.type === "password";
      input.type = show ? "text" : "password";
      btn.querySelector("i").className = show ? "bi bi-eye-slash" : "bi bi-eye";
      btn.setAttribute("aria-label", show ? "Hide password" : "Show password");
    });
  });

  /* ---------- Live validation ---------- */
  password.addEventListener("input", () => { updateStrength(); checkMatch(); });
  confirmPassword.addEventListener("input", checkMatch);
  birthdate.addEventListener("input", validateBirthdate);
  birthdate.addEventListener("change", validateBirthdate);
  genderRadios.forEach((r) => r.addEventListener("change", () => genderFeedback.classList.remove("show")));

  /* ---------- Submit ---------- */
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    validateBirthdate();
    updateStrength();
    checkMatch();

    const genderChosen = [...genderRadios].some((r) => r.checked);
    genderFeedback.classList.toggle("show", !genderChosen);
    form.classList.add("was-validated");

    if (!form.checkValidity()) {
      const firstBad = form.querySelector(":invalid");
      if (firstBad) firstBad.focus({ preventScroll: false });
      return;
    }

    // TODO: send the data to your backend here (e.g. fetch("/api/signup", ...)).
    // Never store or log the raw password on the client.
    successEmail.textContent = email.value.trim();
    formView.classList.add("d-none");
    successView.classList.remove("d-none");
  });

  /* ---------- Reset ---------- */
  document.getElementById("resetBtn").addEventListener("click", () => {
    form.reset();
    form.classList.remove("was-validated");
    updateStrength();
    successView.classList.add("d-none");
    formView.classList.remove("d-none");
  });
})();
